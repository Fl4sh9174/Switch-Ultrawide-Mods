If on console, drop 01008DB008C2C000 and 0100ABF008968000 in atmosphere/contents/. Depending on version
For Yuzu, just drop "CompL" into the Mods folder.