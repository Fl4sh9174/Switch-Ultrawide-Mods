Citron is recommended for this mod, i wont support other emulators for now.

- FPS mods are WiP
- You must use both exefs and cheat to mod work as expected
- There are different versions of the FPS mod for this game, pay attention to the name of each mod
- Fov mod will work on both emulators, but you can only use hotkey combos on Citron
- Fov mod can cause a few visual glitches, but you can press ZL+dpad up anytime to back to default value
- Ultrawide Mods are using default HUD (will stretch) to avoid some issues with text/icons
- USE THE MODS AT YOUR OWN RISK!

https://github.com/Fl4sh9174/Switch-Ultrawide-Mods